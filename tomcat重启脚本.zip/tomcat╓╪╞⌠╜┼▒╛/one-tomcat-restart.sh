#!/bin/sh
TOMCAT_PATH=/app/tomcat/tomcat01/bin
echo "TOMCAT_PATH is $TOMCAT_PATH"
echo 


PID=`ps aux | grep /app/tomcat/tomcat01 | grep java | awk '{print $2}'`

if [ -n "$PID" ]; then
        echo "Will kill tomcat: $PID"
        sh "$TOMCAT_PATH/shutdown.sh"
        sleep 6
else   
	echo "No Tomcat Process $PID"
	echo 
	echo 
fi


PID2=`ps aux | grep /app/tomcat/tomcat01 | grep java | awk '{print $2}'`

if [ -n "$PID2" ]; then
        kill -9 $PID2
        echo "Try to kill $PID2"
else 
	echo "No Tomcat Process $PID2"
	echo 
fi

sh "$TOMCAT_PATH/startup.sh"
sleep 3
echo 


PID=`ps aux | grep /app/tomcat/tomcat01 | grep java | awk '{print $2}'`
if [ -n "$PID" ]; then
        echo "Restart tomcat successfully!"
	echo 
else
        echo "Fail to startup tomcat"
	echo 
        exit 1
fi
