#!/bin/bash
#获取XXX项目进程ID
tomcatpid=`ps -ef | grep /app/tomcat | grep -v grep | awk '{print $2}'`
echo "tomcat项目进程ID为：$tomcatpid"
#杀进程
echo "kill tomcat PID..."
for id in $tomcatpid
do
kill -9 $id
done
echo "$tomcatpid已杀死..."
echo "重启tomcat..."

#依照实际路径修改
/app/tomcat/tomcat01/bin/startup.sh
/app/tomcat/tomcat02/bin/startup.sh
/app/tomcat/tomcat03/bin/startup.sh
